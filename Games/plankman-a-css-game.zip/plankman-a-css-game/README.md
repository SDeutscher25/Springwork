# Plankman (a CSS game)

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/XWdrQOg](https://codepen.io/alvaromontoro/pen/XWdrQOg).

Plankman is a pirate-themed version of the classic hangman game. It is developed using HTML and CSS without a single line of code.

The topic of all the sentences is: "Movie titles"